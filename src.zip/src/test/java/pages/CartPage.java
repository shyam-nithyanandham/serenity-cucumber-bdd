package pages;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import pages.applicationMethods.MNMCartPage;

public class CartPage extends PageObject {
	
	MNMCartPage cartPage;
	
	@Step
	public void fnVerifyOrderInCart(String strProductName)
	{
			
		cartPage.fnverifyCartDetails(strProductName);
		
	}

	
	
	
}
