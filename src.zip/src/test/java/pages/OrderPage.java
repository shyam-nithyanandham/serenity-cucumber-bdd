package pages;

import org.openqa.selenium.By;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import pages.applicationMethods.MNMOrderPage;

public class OrderPage extends PageObject{
	
	MNMOrderPage OrderPage;
	
	
	@Step
	public void AddtowishList(String strProductName)
	{
		OrderPage.fnAddtowishList(strProductName);	
		
	}
	
	@Step
	public void GoToWishListPage()
	{
		OrderPage.fnGoToWishListPage();
	}
	
	@Step
	public void GotoCartPage()
	{		
		OrderPage.fnGotoCartPage();
	}
	
	
	@Step
	public void AddtoanyItemswishList(String strProducCount)
	{
		OrderPage.fnAddAnyItemtowishList(strProducCount);	
		
	}	
	
	
	
	
	

}
