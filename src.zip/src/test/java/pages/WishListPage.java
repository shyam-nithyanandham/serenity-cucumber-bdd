package pages;

import net.thucydides.core.annotations.Step;
import pages.applicationMethods.MNMWishListPage;

public class WishListPage {
	
	MNMWishListPage wishlistpage;
	
	@Step
	public void fnVerifyIteminWishList(String strProductNo)
	{
		wishlistpage.fnVerifyNoProductInWishList(strProductNo);
	}
	
	
	@Step
	public String fnSearchTheCheapestItem()
	{
		
		String strRowNumber = wishlistpage.fnSeacrhForLowestPrice();
		return strRowNumber;
	}
	
	@Step
	public String fnAddItemToCart(String strRowNumber)
	{		
		String strProPrice = wishlistpage.fnAddtheItemToCart(strRowNumber);
		return strProPrice;
	}
	
	
	
	

}
