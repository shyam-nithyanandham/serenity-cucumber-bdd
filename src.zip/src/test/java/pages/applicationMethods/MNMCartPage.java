package pages.applicationMethods;


import java.util.List;

import org.openqa.selenium.By;

import junit.framework.Assert;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;



public class MNMCartPage extends PageObject{
	
	
	public void fnverifyCartDetails(String strProductandPrice)
	{
		
		String[] arrProductandPrice = strProductandPrice.split(",");
		
		String strPrdPrice = "£"+arrProductandPrice[1];
						
		String strProductName = $(By.xpath("//table[@class='shop_table shop_table_responsive cart woocommerce-cart-form__contents']/tbody/tr/td[3]")).getText();
    	String strPrice = $(By.xpath("//table[@class='shop_table shop_table_responsive cart woocommerce-cart-form__contents']/tbody/tr/td[4]")).getText();
		String strTotalPrice = $(By.xpath("//table[@class='shop_table shop_table_responsive cart woocommerce-cart-form__contents']/tbody/tr/td[6]")).getText();
		
		
	Assert.assertEquals(arrProductandPrice[0], strProductName);
	//Assert.assertEquals(strPrice,strPrdPrice);
			
	}
	
	

}
