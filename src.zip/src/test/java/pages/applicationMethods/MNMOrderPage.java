package pages.applicationMethods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Step;

public class MNMOrderPage extends PageObject{
	
	@Managed
	WebDriver driver;
	
	
	public void fnAddtowishList(String strProductName)
	{
					
		WebElement element = $(By.xpath("(//li//h2[text()=\""+strProductName+"\"])[1]/../following-sibling::div//a[@data-title=\"Add to wishlist\"]"));
		Actions actions = new Actions(getDriver());
		actions.moveToElement(element);
		actions.perform();
		
		$(By.xpath("(//li//h2[text()=\""+strProductName+"\"])[1]/../following-sibling::div//a[@data-title=\"Add to wishlist\"]")).click();
		$(By.xpath("(//li//h2[text()=\""+strProductName+"\"])[1]/../following-sibling::div//a[@data-title=\"Browse wishlist\"]")).waitUntilVisible();
		
	  
	}
	

	public void fnGoToWishListPage()
	{
		WebElement element = $(By.xpath("(//a[@title='Wishlist'])[1]"));
		Actions actions = new Actions(getDriver());
		actions.moveToElement(element);
		actions.perform();
		
		$(By.xpath("(//a[@title='Wishlist'])[1]")).click();
		//$(By.xpath("//h1[text()='Wishlist']")).waitUntilVisible();
		waitForTextToAppear("Wishlist");
		
	}
	

	public void fnGotoCartPage()
	{
		
		$(By.xpath("(//a[@title='Cart'])[1]")).click();
		$(By.xpath("//h1[text()='Cart']")).waitUntilVisible();
	}
	
	
	public void fnAddAnyItemtowishList(String strItemCount)
	{
		
		int intItemCount = Integer.parseInt(strItemCount);
		
		if(intItemCount<=5)
		{
			
			for(int i=1;i<=intItemCount;i++)
			{
				
				WebElement element = $(By.xpath("(//li[contains(@class,'product type-product post')]["+i+"])[1]//a[@data-title=\"Add to wishlist\"]"));
				Actions actions = new Actions(getDriver());
				actions.moveToElement(element);
				actions.perform();
				
				$(By.xpath("(//li[contains(@class,'product type-product post')]["+i+"])[1]//a[@data-title=\"Add to wishlist\"]")).click();
				$(By.xpath("(//li[contains(@class,'product type-product post')]["+i+"])[1]//a[@data-title=\"Browse wishlist\"]")).waitUntilVisible();
				
				
			}
			
		}
		
		
		if((intItemCount>5) && (intItemCount<9))
		{
			
			intItemCount = intItemCount - 5;
			
			for(int i=1;i<=intItemCount;i++)
			{
				
				WebElement element = $(By.xpath("(//li[contains(@class,'product type-product post')]["+i+"])[2]//a[@data-title=\"Add to wishlist\"]"));
				Actions actions = new Actions(getDriver());
				actions.moveToElement(element);
				actions.perform();
				
				$(By.xpath("(//li[contains(@class,'product type-product post')]["+i+"])[2]//a[@data-title=\"Add to wishlist\"]")).click();
				$(By.xpath("(//li[contains(@class,'product type-product post')]["+i+"])[2]//a[@data-title=\"Browse wishlist\"]")).waitUntilVisible();
				
				
			}
			
			
			
		}
		
		
	  
	}
	
	

}
