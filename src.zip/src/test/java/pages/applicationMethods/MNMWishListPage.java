package pages.applicationMethods;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.openqa.selenium.By;

import junit.framework.Assert;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class MNMWishListPage extends PageObject{
	
	
	@FindBy(xpath = "(//td[@class='product-name'])")
	public List<WebElementFacade> elementItems;
	
	
	public void fnVerifyNoProductInWishList(String strProductCount)
	{
		int intProductCount = Integer.parseInt(strProductCount);
		System.out.print("Size of the webelement : "+ elementItems.size());
		Assert.assertEquals(intProductCount, elementItems.size());				
				
	}
	
	public String fnSeacrhForLowestPrice()
	{
	        int intsizeOfElement = elementItems.size();
	        
	        boolean ASC = true;        
	        
	        
	        Map<String, Double> PrinceMap = new HashMap<String, Double>(); 
	       		
				
	        
	        for(int i=1;i<=intsizeOfElement;i++)
	        {
	        	
	        	String strTempPrice = $(By.xpath("(//td[@class='product-price'])["+i+"]")).getText();
	        	        	
	        	int myval  = strTempPrice.length();
	        	
	        	String strrowNumber = Integer.toString(i);
	        	
	        	if(myval == 15)
	        	{	        		
	        		String strPrice = strTempPrice.substring(10);
	        		
	        		double dblPrice = Double.parseDouble(strPrice);
	        		     		
	        		PrinceMap.put(strrowNumber, dblPrice);
	        		 
	        	}
	        	else if(myval == 13)
	        	{
	        		String strPrice = $(By.xpath("(//td[@class='product-price'])["+i+"]/ins")).getText();
	        		      		
	        		strPrice = strPrice.substring(strPrice.indexOf("£")+1);
	        		       		 
	        		 double dblPrice = Double.parseDouble(strPrice);
	        		
	        		 PrinceMap.put(strrowNumber, dblPrice);
	        	}
	        	else
	        	{
	        		 String strPrice = strTempPrice.substring(strTempPrice.indexOf("£")+1);
	        		        	       		 
	        		 double dblPrice = Double.parseDouble(strPrice);
		        		
	        		 PrinceMap.put(strrowNumber, dblPrice);
	        	}
	          	
	        
	        	
	        	
	        }
	        
	        Map<String, Double> sortedMapAsc = sortByComparator(PrinceMap, ASC);
	        
	        Map.Entry<String,Double> entry = sortedMapAsc.entrySet().iterator().next();
	    	String key= entry.getKey();
	    	Double value=entry.getValue(); 
	    	
	    	String strPriceVal = value.toString();
	    	    		    	        	
	       return key+","+strPriceVal;
	       
	}
	
	
	public String fnAddtheItemToCart(String strProductRowCount)
	
	{
		
		String[] arrValue = strProductRowCount.split(",");
		
		
		String strProductName = $(By.xpath("//table/tbody/tr["+arrValue[0]+"]/td[3]")).getText();
    	String strPrice = $(By.xpath("//table/tbody/tr["+arrValue[0]+"]/td[4]")).getText();
    	
    	$(By.xpath("//table/tbody/tr["+arrValue[0]+"]/td[6]/a")).click();
    	
    	String strsuccessMsg = $(By.xpath("//div[@class='woocommerce-notices-wrapper']/div")).getText();
    	
    	Assert.assertEquals(strsuccessMsg, "Product added to cart successfully");
    	  	
    	
    	return strProductName+","+arrValue[1];
    	
	}
		
	
	
	private static Map<String, Double> sortByComparator(Map<String, Double> princeMap, final boolean order)
    {

        List<Entry<String, Double>> list = new LinkedList<Entry<String, Double>>(((Map<String, Double>) princeMap).entrySet());

        // Sorting the list based on values
        Collections.sort(list, new Comparator<Entry<String, Double>>()
        {
            public int compare(Entry<String, Double> o1,
                    Entry<String, Double> o2)
            {
                if (order)
                {
                    return o1.getValue().compareTo(o2.getValue());
                }
                else
                {
                    return o2.getValue().compareTo(o1.getValue());

                }
            }
        });

        // Maintaining insertion order with the help of LinkedList
        Map<String, Double> sortedMap = new LinkedHashMap<String, Double>();
        for (Entry<String, Double> entry : list)
        {
            sortedMap.put(entry.getKey(), entry.getValue());
        }

        return sortedMap;
    }
	

}
