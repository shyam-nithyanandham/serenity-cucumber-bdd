package starter.navigation;


import net.thucydides.core.annotations.Step;

public class NavigateTo {
	
	

    OnlineShopHomePage OnlineShopHomePage;

    @Step("Open the online shop home page")
    public void theOnlineShopHomePage() {
    	OnlineShopHomePage.open();
    }
}
