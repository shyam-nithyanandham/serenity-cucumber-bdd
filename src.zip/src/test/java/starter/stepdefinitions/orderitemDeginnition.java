package starter.stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import pages.CartPage;
import pages.OrderPage;
import pages.WishListPage;
import starter.navigation.NavigateTo;


public class orderitemDeginnition {
	
	@Steps
	OrderPage  orderPage;
	
	@Steps
	WishListPage wishlistPage;
	
	@Steps
	CartPage cartPage;
	
	@Steps
    NavigateTo navigateTo;
	
	String strRowNumber,strProdAndPrice;
	
	@Given("I open the order page")
	    public void InvokeApplication() {
		navigateTo.theOnlineShopHomePage();
	    }

		
	
	@Given("I added {string} product to my wish list")
	public void i_added_product_to_my_wish_list(String strProdName) {
	   orderPage.AddtowishList(strProdName);
	}
	
	@Given("I add four different products to my wish list")
	public void i_add_four_different_products_to_my_wish_list() {
		orderPage.AddtoanyItemswishList("4");
	}

	@When("I view my wishlist table")
	public void i_view_my_wishlist_table() {
	    orderPage.GoToWishListPage();
	    
	}
	
	
	@Then("I find total {string} selected items in my wishlist")
	public void i_find_total_selected_items_in_my_wishlist(String strProductCount) {
		wishlistPage.fnVerifyIteminWishList(strProductCount);
	}

	@When("I search for lowest price product")
	public void i_search_for_lowest_price_product() {
		strRowNumber = wishlistPage.fnSearchTheCheapestItem();
		
	    
	}
	

	@When("I am able to add the lowest item to my cart")
	public void i_am_able_to_add_the_lowest_item_to_my_cart() {
			strProdAndPrice = wishlistPage.fnAddItemToCart(strRowNumber);
						
	}

	@Then("I am able to verify the item in my cart")
	public void i_am_able_to_verify_the_item_in_my_cart() {
		
		orderPage.GotoCartPage();
		cartPage.fnVerifyOrderInCart(strProdAndPrice);
	  
	}


}
